"""
Helpers to locate and invoke the Axon CLI across different environments.
"""

from __future__ import annotations

import importlib.util
import os
import shlex
import shutil
import sys
from functools import lru_cache
from pathlib import Path


def _is_executable(path: Path) -> bool:
    if os.name == "nt":
        return path.is_file()
    return path.is_file() and os.access(path, os.X_OK)


def _split_env_command(raw: str) -> list[str]:
    # Use Windows-compatible splitting when running on Windows.
    return shlex.split(raw, posix=os.name != "nt")


@lru_cache(maxsize=1)
def resolve_axon_base_cmd() -> tuple[str, ...]:
    """Resolve a command prefix that can execute Axon.

    Resolution order:
    1. AXON_BIN override, if set (for custom deployment setups).
    2. Script next to current Python executable (venv-safe).
    3. `axon` available on PATH.
    4. Python module launch fallback: `python -m axon`.
    """
    env_override = os.getenv("AXON_BIN")
    if env_override:
        cmd = _split_env_command(env_override.strip())
        if cmd:
            return tuple(cmd)

    scripts_dir = Path(sys.executable).resolve().parent
    for name in ("axon", "axon.exe", "axon.cmd", "axon.bat"):
        candidate = scripts_dir / name
        if _is_executable(candidate):
            return (str(candidate),)

    path_hit = shutil.which("axon")
    if path_hit:
        return (path_hit,)

    if importlib.util.find_spec("axon") is not None:
        return (sys.executable, "-m", "axon")

    raise FileNotFoundError(
        "Axon CLI not found in this environment. Install it with "
        "`python -m pip install axon` in the same Python environment used "
        "to run `codetalk`."
    )


def axon_cmd(*args: str) -> list[str]:
    return [*resolve_axon_base_cmd(), *args]
