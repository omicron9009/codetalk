"""
Step 3: ensure Ollama is available, running, and model is present.
If Ollama is missing, codetalk attempts a best-effort installation.
"""
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path

import requests

OLLAMA_BASE = "http://localhost:11434"
MODEL = "codellama:7b"


def start() -> subprocess.Popen | None:
    """Ensure Ollama and model are ready.

    Returns a process handle only when codetalk starts `ollama serve` itself.
    """
    ollama_cmd = _resolve_or_install_ollama()
    ollama_proc = _ensure_ollama_running(ollama_cmd)
    _ensure_model_available(ollama_cmd)
    _warm_model()
    return ollama_proc


def _resolve_or_install_ollama() -> str:
    ollama_cmd = _find_ollama_binary()
    if ollama_cmd:
        return ollama_cmd

    print("[llm] Ollama binary not found. Attempting automatic installation...")
    _attempt_ollama_install()

    ollama_cmd = _find_ollama_binary()
    if ollama_cmd:
        print(f"[llm] Ollama installed successfully: {ollama_cmd}")
        return ollama_cmd

    print("[llm] ERROR: Could not install Ollama automatically.")
    print("[llm] Install manually from https://ollama.com/download and retry.")
    sys.exit(1)


def _find_ollama_binary() -> str | None:
    from_path = shutil.which("ollama")
    if from_path:
        return from_path

    for candidate in _candidate_ollama_paths():
        if candidate.exists():
            return str(candidate)
    return None


def _candidate_ollama_paths() -> list[Path]:
    system = platform.system()
    home = Path.home()

    if system == "Windows":
        return [
            home / "AppData" / "Local" / "Programs" / "Ollama" / "ollama.exe",
            Path("C:/Program Files/Ollama/ollama.exe"),
        ]
    if system == "Darwin":
        return [
            Path("/usr/local/bin/ollama"),
            Path("/opt/homebrew/bin/ollama"),
        ]
    return [
        Path("/usr/local/bin/ollama"),
        Path("/usr/bin/ollama"),
    ]


def _attempt_ollama_install() -> None:
    system = platform.system()
    commands: list[list[str]] = []

    if system == "Windows":
        commands.append(
            [
                "winget",
                "install",
                "-e",
                "--id",
                "Ollama.Ollama",
                "--accept-package-agreements",
                "--accept-source-agreements",
            ]
        )
    elif system == "Darwin":
        commands.append(["brew", "install", "ollama"])
    else:
        commands.append(["sh", "-c", "curl -fsSL https://ollama.com/install.sh | sh"])
        commands.append(["sh", "-c", "wget -qO- https://ollama.com/install.sh | sh"])

    for cmd in commands:
        tool = cmd[0]
        if tool not in {"sh"} and shutil.which(tool) is None:
            continue

        print(f"[llm] Trying install command: {' '.join(cmd[:3])} ...")
        try:
            result = subprocess.run(cmd)
        except Exception:
            continue

        if result.returncode == 0:
            return


def _ensure_ollama_running(ollama_cmd: str) -> subprocess.Popen | None:
    if _is_ollama_reachable():
        print("[llm] Ollama is reachable.")
        return None

    print("[llm] Ollama is not running. Starting `ollama serve`...")
    try:
        proc = subprocess.Popen(
            [ollama_cmd, "serve"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except OSError as e:
        print(f"[llm] ERROR: Failed to start Ollama: {e}")
        sys.exit(1)

    if _wait_for_ollama():
        return proc

    if proc.poll() is not None:
        print("[llm] ERROR: `ollama serve` exited before becoming ready.")
    else:
        print("[llm] ERROR: Timed out waiting for Ollama to start.")
    sys.exit(1)


def _wait_for_ollama(retries: int = 20, delay_seconds: int = 2) -> bool:
    for i in range(retries):
        if _is_ollama_reachable():
            print("[llm] Ollama is reachable.")
            return True
        print(f"[llm] Waiting for Ollama... ({i + 1}/{retries})")
        time.sleep(delay_seconds)
    return False


def _is_ollama_reachable() -> bool:
    try:
        r = requests.get(f"{OLLAMA_BASE}/api/tags", timeout=2)
        return r.status_code == 200
    except requests.ConnectionError:
        return False
    except Exception:
        return False


def _ensure_model_available(ollama_cmd: str) -> None:
    if _has_model(ollama_cmd, MODEL):
        print(f"[llm] Model \"{MODEL}\" is already available.")
        return

    print(f"[llm] Model \"{MODEL}\" not found. Pulling now...")
    result = subprocess.run([ollama_cmd, "pull", MODEL])
    if result.returncode != 0:
        print(f"[llm] ERROR: Failed to pull model \"{MODEL}\".")
        sys.exit(1)
    print(f"[llm] Model \"{MODEL}\" pulled successfully.")


def _has_model(ollama_cmd: str, model: str) -> bool:
    try:
        result = subprocess.run(
            [ollama_cmd, "list"],
            capture_output=True,
            text=True,
            timeout=30,
        )
    except Exception:
        return False

    if result.returncode != 0:
        return False

    for line in result.stdout.splitlines():
        raw = line.strip()
        if not raw:
            continue
        if raw.lower().startswith("name"):
            continue
        model_name = raw.split()[0]
        if model_name == model:
            return True
    return False


def _warm_model() -> None:
    """Pre-load the model so the first user query is not slow."""
    try:
        requests.post(
            f"{OLLAMA_BASE}/api/generate",
            json={"model": MODEL, "prompt": "ping", "stream": False},
            timeout=60,
        )
        print(f"[llm] Model \"{MODEL}\" is warm.")
    except Exception as e:
        print(f"[llm] WARNING: Could not warm model: {e}")
