"""
Step 1: Index the codebase with Axon.
This must finish before any other service starts.
Runs `axon analyze <path>` and blocks until done.
"""

import subprocess
import sys
from pathlib import Path

from codetalk.axon_cli import axon_cmd


def run(project_path: Path) -> None:
    try:
        cmd = axon_cmd("analyze", str(project_path))
    except FileNotFoundError as exc:
        print(f"[indexer] ERROR: {exc}")
        sys.exit(1)

    result = subprocess.run(cmd)
    if result.returncode != 0:
        print("[indexer] ERROR: `axon analyze` failed. Is axon installed?")
        sys.exit(1)

    print("[indexer] Done - codebase is indexed.")

