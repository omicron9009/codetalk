"""codetalk - Talk to your codebase locally."""

__version__ = "0.5.0"
