"""
FastAPI application — the public interface.
POST /chat   accepts a question, returns the LLM answer.
GET  /health returns 200 if the service is alive.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from codetalk.api import llm, mcp

app = FastAPI(title="codetalk", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class ChatRequest(BaseModel):
    question: str


class ChatResponse(BaseModel):
    answer: str
    used_code_context: bool


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    # Try to get structured context from Axon first
    code_context = await mcp.query(req.question)

    answer = await llm.ask(
        question=req.question,
        code_context=code_context,
    )
    return ChatResponse(
        answer=answer,
        used_code_context=bool(code_context),
    )
