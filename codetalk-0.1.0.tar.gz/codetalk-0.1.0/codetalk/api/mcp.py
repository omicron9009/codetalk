"""
MCP client — queries Axon on port 8001.
Only calls Axon when the question looks code-related.
Degrades gracefully if Axon is unreachable.
"""
import httpx

MCP_URL = "http://localhost:8001"

CODE_KEYWORDS = [
    "function", "class", "method", "call", "import", "module",
    "where", "defined", "uses", "breaks", "depends", "returns",
    "variable", "error", "exception", "file", "path", "symbol",
]


async def query(question: str) -> str:

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(
                f"{MCP_URL}/query",
                json={"query": question},
            )
            resp.raise_for_status()
            return resp.json().get("context", "")[:2000]
    except Exception:
        return ""


def _is_code_question(question: str) -> bool:
    lower = question.lower()
    return any(kw in lower for kw in CODE_KEYWORDS)
