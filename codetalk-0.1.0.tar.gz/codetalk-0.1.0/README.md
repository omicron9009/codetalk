# codetalk

> Point to a project. Talk to it.

## Prerequisites

- Python 3.10+
- [axon](https://github.com/harshkedia177/axon) on PATH
- [Ollama](https://ollama.com) running: `ollama serve`
- Model pulled: `ollama pull codellama:7b`

## Quickstart

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
codetalk --serv /path/to/your/project
```

Open: **http://localhost:8080**

## Ports

| Port | Service   | Purpose              |
|------|-----------|----------------------|
| 8000 | FastAPI   | Chat API + LLM glue  |
| 8001 | Axon MCP  | Code graph queries   |
| 8080 | Static UI | Browser chat         |
