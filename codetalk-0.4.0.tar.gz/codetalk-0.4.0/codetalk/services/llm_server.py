"""
Step 3: Verify Ollama is up and warm the model into RAM.
Ollama runs as a system daemon — we do NOT launch it here.
Prerequisites:
    ollama serve          (run once, system-level)
    ollama pull codellama:7b
"""
import sys
import time

import requests

OLLAMA_BASE = "http://localhost:11434"
MODEL = "codellama:7b"


def start() -> None:
    _wait_for_ollama()
    _warm_model()


def _wait_for_ollama(retries: int = 10) -> None:
    for i in range(retries):
        try:
            r = requests.get(f"{OLLAMA_BASE}/api/tags", timeout=2)
            if r.status_code == 200:
                print("[llm] Ollama is reachable.")
                return
        except requests.ConnectionError:
            pass
        print(f"[llm] Waiting for Ollama... ({i + 1}/{retries})")
        time.sleep(2)
    print("[llm] ERROR: Ollama is not running. Run: ollama serve")
    sys.exit(1)


def _warm_model() -> None:
    """Pre-load the model so the first user query is not slow."""
    try:
        requests.post(
            f"{OLLAMA_BASE}/api/generate",
            json={"model": MODEL, "prompt": "ping", "stream": False},
            timeout=60,
        )
        print(f"[llm] Model \"{MODEL}\" is warm.")
    except Exception as e:
        print(f"[llm] WARNING: Could not warm model: {e}")
