"""
Step 2: Expose Axon as an MCP server (launched with `axon mcp`).
This gives the LLM a structured way to query the code graph.
"""
import logging
import os
import subprocess
import threading
import sys
from pathlib import Path


def start(project_path: Path) -> subprocess.Popen:
    """Launch `axon mcp` as a background process and capture its logs.

    The command used is strictly ["axon", "mcp"] so nothing else is executed.
    Logs are written to <project_path>/axon_mcp.log to help with debugging connection issues.
    """
    log_path = project_path / "axon_mcp.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    # Open file in append-binary so we can write process output to it
    log_file = open(log_path, "ab")

    # Start axon mcp and capture its stdout/stderr so we can tee it to the
    # terminal (stdout) and the log file for later inspection.
    proc = subprocess.Popen(
        ["axon", "mcp"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        cwd=str(project_path),
    )

    def _tee_output(stream, out_file):
        try:
            while True:
                chunk = stream.readline()
                if not chunk:
                    break
                # write raw bytes to log file
                out_file.write(chunk)
                out_file.flush()
                # also print decoded text to parent stdout for visibility
                try:
                    text = chunk.decode("utf-8", errors="replace")
                except Exception:
                    text = str(chunk)
                sys.stdout.write(text)
                sys.stdout.flush()
        finally:
            try:
                stream.close()
            except Exception:
                pass
            try:
                out_file.close()
            except Exception:
                pass

    tee_thread = threading.Thread(target=_tee_output, args=(proc.stdout, log_file), daemon=True)
    tee_thread.start()

    # Keep references so GC doesn't close them unexpectedly
    proc._axon_log_file = log_file
    proc._axon_log_thread = tee_thread
    # Export the project path so child processes (the API server) know where
    # the Axon index lives and can run `axon query`/`axon analyze` in the
    # correct directory.
    os.environ.setdefault("AXON_PROJECT_PATH", str(project_path))

    logging.getLogger(__name__).info("[mcp_server] started axon mcp, log=%s", log_path)
    return proc
