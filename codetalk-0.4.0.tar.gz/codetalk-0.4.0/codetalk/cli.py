"""
CLI entrypoint.
Single command: codetalk --serv /path/to/project
Boots everything in order: index → mcp → llm → api → ui
"""
import argparse
import sys
import time
from pathlib import Path

from codetalk.services import indexer, mcp_server, llm_server, api_server, ui_server
import logging


def main():
    # Ensure basic logging is configured for backend traces
    logging.basicConfig(level=logging.INFO)

    parser = argparse.ArgumentParser(
        prog="codetalk",
        description="Talk to your codebase locally.",
    )
    parser.add_argument(
        "--serv",
        metavar="PROJECT_PATH",
        required=True,
        help="Path to the project you want to chat with.",
    )
    args = parser.parse_args()
    project_path = Path(args.serv).resolve()

    if not project_path.exists():
        print(f"[codetalk] ERROR: Path does not exist: {project_path}")
        sys.exit(1)

    print(f"[codetalk] Indexing project at {project_path} ...")
    indexer.run(project_path)

    print("[codetalk] Starting MCP server (axon mcp) ...")
    mcp_proc = mcp_server.start(project_path)

    print("[codetalk] Starting LLM (codellama:7b via Ollama) ...")
    llm_server.start()

    time.sleep(2)

    print("[codetalk] Starting API server on port 8000 ...")
    api_proc = api_server.start()

    print("[codetalk] Starting UI on port 8080 ...")
    ui_proc = ui_server.start()

    print()
    print("=" * 50)
    print("[codetalk] All services are running!")
    print("  Chat UI  ->  http://localhost:8080")
    print("  API docs ->  http://localhost:8000/docs")
    print("  MCP      ->  axon mcp (local)")
    print("=" * 50)

    procs = [mcp_proc, api_proc, ui_proc]
    try:
        while True:
            for p in procs:
                if p.poll() is not None:
                    print("[codetalk] A service exited unexpectedly. Shutting down.")
                    for other in procs:
                        other.terminate()
                    sys.exit(1)
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[codetalk] Shutting down...")
        for p in procs:
            p.terminate()


if __name__ == "__main__":
    main()
