# codetalk

> Point to a project. Talk to it.

## Prerequisites

- Python 3.11+
- [Ollama](https://ollama.com) running: `ollama serve`
- Model pulled: `ollama pull codellama:7b`
- `axon` CLI (installed automatically via `axoniq` when you install `codetalk`)

## Quickstart

```bash
pip install codetalk
codetalk --serv /path/to/your/project
```

Open: **http://localhost:8080**

## Ports

| Port | Service | Purpose |
|------|---------|---------|
| 8000 | FastAPI | Chat API + LLM glue |
| N/A  | Axon MCP (`axon mcp`) | Code graph queries |
| 8080 | Static UI | Browser chat |
