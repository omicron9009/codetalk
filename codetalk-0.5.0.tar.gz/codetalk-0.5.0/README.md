# codetalk

Talk to a local codebase through a simple browser UI backed by:
- Axon (`axon`) for code indexing and code-aware retrieval
- Ollama (`codellama:7b`) for LLM responses
- FastAPI for chat orchestration
- A static HTML frontend for chat interaction

This README is a full technical deep dive of this repository: idea, architecture, logic flow, file-by-file map, install/build/release, and operations.

## 1) Product Idea and Scope

`codetalk` is a local-first code assistant launcher. You point it at a project directory and it starts a small multi-process stack that:

1. Indexes the target project with Axon.
2. Starts Axon MCP mode for code graph access.
3. Verifies Ollama is reachable and warms a model.
4. Starts a FastAPI backend (`/chat`, `/health`).
5. Starts a static chat UI on port `8080`.

Design goals in current implementation:
- Minimal setup after install.
- No frontend build toolchain.
- Single CLI command for end users:
  - `codetalk --serv path/to/dir`

Non-goals in current implementation:
- Auth and multi-user isolation.
- HTTPS/TLS termination.
- Horizontal scaling.
- Advanced production process manager integration.

## 2) High-Level Architecture

### Runtime Processes

When the CLI runs, the process model is:

1. Parent process: `codetalk` CLI
2. Child process: `axon mcp`
3. Child process: `uvicorn codetalk.api.app:app --host 0.0.0.0 --port 8002 --reload`
4. Child process: `python -m http.server 8080 --directory codetalk/ui`

Ollama lifecycle is handled by codetalk at runtime:
- If `ollama` is missing, codetalk attempts an automatic install.
- If Ollama is not running, codetalk starts `ollama serve`.
- If `codellama:7b` is missing, codetalk runs `ollama pull codellama:7b`.

### Service Topology

- Browser UI -> `http://localhost:8080` (static file server)
- UI POST -> `http://localhost:8002/chat` (FastAPI)
- FastAPI -> `axon query ...` (subprocess CLI call)
- FastAPI -> `http://localhost:11434/api/generate` (Ollama API)

## 3) Startup Logic (Exact Sequence)

The CLI entrypoint (`codetalk/cli.py`) executes these steps:

1. Parse `--serv PROJECT_PATH`.
2. Resolve the path and fail fast if it does not exist.
3. Run blocking index phase:
   - `axon analyze <project_path>`
4. Start MCP process:
   - `axon mcp`
   - tee MCP output to both terminal and `<project_path>/axon_mcp.log`
   - export `AXON_PROJECT_PATH` for child access
5. Ensure Ollama is installed:
   - auto-detect `ollama` command
   - if missing, run OS-specific best-effort installer
6. Ensure Ollama daemon is running:
   - poll `http://localhost:11434/api/tags`
   - if not reachable, start `ollama serve` and wait
7. Ensure model exists:
   - check `ollama list`
   - if missing, run `ollama pull codellama:7b`
8. Warm model:
   - POST `http://localhost:11434/api/generate` with prompt `"ping"`
9. Sleep 2 seconds.
10. Start API server on port `8002`.
11. Start static UI server on port `8080`.
12. Monitor child processes:
     - if any child exits unexpectedly, terminate others and exit non-zero.
13. On Ctrl+C:
     - terminate all child processes.

## 4) Chat Request Flow (End-to-End)

### Browser Layer (`codetalk/ui/index.html`)

1. User enters question.
2. UI appends user bubble.
3. UI appends temporary `"Thinking..."` bot bubble.
4. UI sends:
   - `POST http://localhost:8002/chat`
   - JSON body: `{ "question": "<user text>" }`
5. UI replaces temporary bubble with returned answer.
6. If `used_code_context=true`, append a context badge.

### API Layer (`codetalk/api/app.py`)

1. Validate request with Pydantic model `ChatRequest`.
2. Log incoming question.
3. Query code context via `await mcp.query(question)`.
4. Ask LLM via `await llm.ask(question, code_context)`.
5. Return `ChatResponse`:
   - `answer`
   - `used_code_context` boolean.

### Code Retrieval Layer (`codetalk/api/mcp.py`)

1. Determine project cwd:
   - `AXON_PROJECT_PATH` env var (preferred)
   - else current working directory
2. Execute `axon query "<question>"` via subprocess.
3. Capture stdout/stderr.
4. If output indicates missing index:
   - attempt `axon analyze <project_path>`
   - retry query once
5. Clip context to 10000 chars.
6. Return context string (or empty string on failure).

### LLM Layer (`codetalk/api/llm.py`)

1. Build prompt:
   - include Axon context block if present
   - include user question
2. Call Ollama generate endpoint with:
   - model: `codellama:7b`
   - system prompt requiring context-grounded responses
   - non-streaming response
3. Return `response` field text.

## 5) API Contract

### `GET /health`

- Response:
```json
{"status":"ok"}
```

### `POST /chat`

- Request:
```json
{"question":"Where is the auth middleware defined?"}
```

- Response:
```json
{
  "answer": "...",
  "used_code_context": true
}
```

## 6) Installation and Run

## 6.1 Production-style user flow (two commands)

Prerequisites:
- Python `3.11+`
- Internet access on first run (for Ollama installer/model pull if needed)
- System permissions that allow package installation tools (for auto-install path)

Install and run:
```bash
pip install codetalk
codetalk --serv path/to/dir
```

Open:
- `http://localhost:8080` (chat UI)
- `http://localhost:8002/docs` (FastAPI docs)

## 6.2 Local source install

From repository root:
```bash
python -m pip install --upgrade pip
pip install .
codetalk --serv path/to/dir
```

## 6.3 Validate external dependencies

```bash
python --version
axon --help
ollama --version
```

If `axon` command is missing after install, reinstall in a clean environment and ensure `axon` dependency was resolved.
If `ollama` command is missing, codetalk will attempt to install it automatically at startup.

## 7) Build, Package, and Release

## 7.1 Build artifacts

```bash
python -m pip install --upgrade pip setuptools wheel build
python -m build
```

Outputs in `dist/`:
- `*.whl` (wheel, recommended for installs)
- `*.tar.gz` (sdist, source fallback)

If you only need wheel:
```bash
python -m build --wheel
```

## 7.2 Local artifact verification

```bash
pip install dist/codetalk-0.5.0-py3-none-any.whl
codetalk --serv path/to/dir
```

## 7.3 Publish (if needed)

```bash
python -m pip install --upgrade twine
twine check dist/*
twine upload dist/*
```

## 8) Configuration Surfaces (Current Hardcoded Values)

- API URL in UI: `http://localhost:8002`
- API bind host/port: `0.0.0.0:8002`
- UI server port: `8080`
- Ollama base URL: `http://localhost:11434`
- Default model: `codellama:7b`
- CORS policy: `allow_origins=["*"]`

Operational implication:
- This is local-development-friendly by default.
- For hardened deployments, reverse proxy and stricter network/security settings are recommended.

## 9) Dependency Map

Declared in `pyproject.toml` and mirrored in `requirements.txt`:

- `fastapi`: HTTP API framework.
- `uvicorn`: ASGI server for FastAPI.
- `httpx`: async HTTP client for Ollama calls.
- `requests`: sync HTTP checks/warm-up in startup service.
- `pydantic`: request/response schema validation.
- `axon`: provides `axon` CLI used by index/query/mcp.

## 10) Deep File-by-File Reference

This section documents every file currently present in the project directory tree (excluding virtualenv internals and Python bytecode caches).

## 10.1 Root-level source/config files

| File | Purpose | Notes |
|---|---|---|
| `.gitignore` | Ignore local/dev/build artifacts | Ignores `.venv*`, `build/`, `dist/`, `.axon/`, egg-info, caches |
| `Makefile` | Convenience dev commands | Uses Unix-style paths; mostly for local dev |
| `MANIFEST.in` | Source distribution include rules | Includes `README.md` and `codetalk/ui/*.html` |
| `pyproject.toml` | Canonical package metadata | Version, dependencies, console script, package data |
| `README.md` | Project documentation | This file |
| `requirements.txt` | Flat dependency list | Mirrors runtime dependencies for convenience |
| `scaffold.py` | One-time project scaffolding script | Creates folder/file skeleton |
| `setup.py` | Setuptools shim entry | Delegates to `pyproject.toml` metadata (`setup()`) |
| `.vscode/settings.json` | Editor setting | Enables makefile configure-on-open |
| `.axon/kuzu` | Axon runtime database artifact | Generated by Axon analyze/query lifecycle |

## 10.2 Main Python package (`codetalk/`)

| File | Purpose | Key Logic |
|---|---|---|
| `codetalk/__init__.py` | Package marker and internal version constant | Defines `__version__` |
| `codetalk/cli.py` | Primary entrypoint (`codetalk` command) | Orchestrates startup sequence and child process supervision |
| `codetalk/api/__init__.py` | API package marker | Empty marker module |
| `codetalk/api/app.py` | FastAPI app and endpoints | `/health`, `/chat`, CORS, request/response models |
| `codetalk/api/llm.py` | Ollama client | Prompt composition + async generate call |
| `codetalk/api/mcp.py` | Axon query client | Runs `axon query`, fallback `axon analyze`, returns context |
| `codetalk/services/__init__.py` | Services package marker | Empty marker module |
| `codetalk/services/indexer.py` | Indexing step service | Blocking `axon analyze` and fail-fast on error |
| `codetalk/services/mcp_server.py` | MCP process launcher | Starts `axon mcp`, logs to file + stdout tee |
| `codetalk/services/llm_server.py` | Ollama bootstrap service | Installs/checks Ollama, starts daemon, pulls model, warms model |
| `codetalk/services/api_server.py` | Uvicorn launcher | Starts FastAPI process on port `8002` |
| `codetalk/services/ui_server.py` | Static UI launcher | Starts Python http.server on port `8080` |
| `codetalk/ui/index.html` | Single-page chat UI | Minimal JS client for `/chat` endpoint |

## 10.3 Generated build mirror (`build/lib/`)

These files are generated packaging copies of the source package. They mirror runtime code and should not be edited manually.

| File |
|---|
| `build/lib/codetalk/__init__.py` |
| `build/lib/codetalk/cli.py` |
| `build/lib/codetalk/api/__init__.py` |
| `build/lib/codetalk/api/app.py` |
| `build/lib/codetalk/api/llm.py` |
| `build/lib/codetalk/api/mcp.py` |
| `build/lib/codetalk/services/__init__.py` |
| `build/lib/codetalk/services/api_server.py` |
| `build/lib/codetalk/services/indexer.py` |
| `build/lib/codetalk/services/llm_server.py` |
| `build/lib/codetalk/services/mcp_server.py` |
| `build/lib/codetalk/services/ui_server.py` |
| `build/lib/codetalk/ui/index.html` |

## 10.4 Packaging metadata (`codetalk.egg-info/`)

Generated metadata produced by setuptools build/install flows.

| File | Purpose |
|---|---|
| `codetalk.egg-info/PKG-INFO` | Expanded package metadata |
| `codetalk.egg-info/SOURCES.txt` | Source file manifest |
| `codetalk.egg-info/requires.txt` | Resolved dependency list |
| `codetalk.egg-info/entry_points.txt` | Console script entrypoint map |
| `codetalk.egg-info/top_level.txt` | Top-level Python package names |
| `codetalk.egg-info/dependency_links.txt` | Legacy dependency links (empty in this project) |

## 10.5 Distribution artifacts (`dist/`)

Release outputs from multiple historical versions:

| File |
|---|
| `dist/codetalk-0.1.0-py3-none-any.whl` |
| `dist/codetalk-0.1.0.tar.gz` |
| `dist/codetalk-0.2.0-py3-none-any.whl` |
| `dist/codetalk-0.2.0.tar.gz` |
| `dist/codetalk-0.3.0-py3-none-any.whl` |
| `dist/codetalk-0.3.0.tar.gz` |
| `dist/codetalk-0.4.0-py3-none-any.whl` |
| `dist/codetalk-0.4.0.tar.gz` |
| `dist/codetalk-0.4.1-py3-none-any.whl` |
| `dist/codetalk-0.4.1.tar.gz` |

## 11) Logging and Runtime Artifacts

- CLI logs startup milestones and process failures.
- FastAPI logs user question, retrieved context, and LLM output (truncated safeguard exists in code).
- Axon MCP output is captured into:
  - `<served_project_path>/axon_mcp.log`
- Axon index data appears in target project (for example `.axon/` data).

## 12) Troubleshooting

## 12.1 `codetalk: command not found`

Use module launch to verify install context:
```bash
python -m codetalk.cli --serv path/to/dir
```

If this works but `codetalk` does not, your script path is not on `PATH`.

## 12.2 `axon analyze` fails

Checks:
```bash
axon --help
python -m pip show axon
```

Ensure installation happened in the same Python environment used to run `codetalk`.

## 12.3 Ollama not reachable

codetalk auto-starts Ollama if possible. If it still fails:
```bash
ollama serve
curl http://localhost:11434/api/tags
```

## 12.4 Model not available

codetalk auto-pulls `codellama:7b`. If pull fails due network/disk:
```bash
ollama pull codellama:7b
ollama list
```

## 12.5 UI shows API unreachable

Verify backend is running:
- `http://localhost:8002/health`
- `http://localhost:8002/docs`

## 13) Current Operational Constraints

- API runs with `--reload` in launcher, which is convenient for development but not optimized for hardened production runtime behavior.
- No authentication on `/chat`.
- CORS currently allows all origins.
- Uses local ports and local process spawning assumptions.

These are intentional current behavior characteristics from the codebase as it stands.

## 14) Quick Command Reference

Install package:
```bash
pip install codetalk
```

Run:
```bash
codetalk --serv path/to/dir
```

Build release artifacts:
```bash
python -m build
```

Clean generated artifacts (manual):
```bash
rm -rf build dist *.egg-info
```
