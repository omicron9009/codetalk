"""
Step 4: Start the FastAPI service on port 8000.
This is the glue — it talks to both Ollama and Axon MCP.
"""
import subprocess


def start() -> subprocess.Popen:
    proc = subprocess.Popen(
        [
            "uvicorn", "codetalk.api.app:app",
            "--host", "0.0.0.0",
            "--port", "8000",
            "--reload",
        ]
    )
    return proc
