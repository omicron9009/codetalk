"""
Step 1: Index the codebase with Axon.
This must finish before any other service starts.
Runs `axon analyze <path>` and blocks until done.
"""
import subprocess
import sys
from pathlib import Path


def run(project_path: Path) -> None:
    result = subprocess.run(
        ["axon", "analyze", str(project_path)],
    )
    if result.returncode != 0:
        print("[indexer] ERROR: `axon analyze` failed. Is axon installed?")
        sys.exit(1)
    print("[indexer] Done — codebase is indexed.")
