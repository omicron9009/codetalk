"""
MCP client — sends query strings to Axon via the local `axon mcp` process.
Only calls Axon when the question looks code-related.
Degrades gracefully if Axon is unreachable.
"""
import asyncio
import logging
import os
import subprocess

logger = logging.getLogger(__name__)

CODE_KEYWORDS = [
    "function", "class", "method", "call", "import", "module",
    "where", "defined", "uses", "breaks", "depends", "returns",
    "variable", "error", "exception", "file", "path", "symbol",
]


async def query(question: str) -> str:
    """Always send the user's raw question to Axon via the CLI and return
    the resulting context (clipped to 2000 chars). This runs the blocking
    subprocess call in a thread to avoid blocking the event loop.
    """
    logger.info("[mcp] axon query: %s", question)

    project_path = os.getenv("AXON_PROJECT_PATH") or os.getcwd()

    def _run_query(q: str) -> str:
        try:
            # Call axon CLI: `axon query "<q>"` in the indexed project dir
            res = subprocess.run(["axon", "query", q], capture_output=True, text=True, timeout=20, cwd=project_path)
            out = (res.stdout or "")
            if res.returncode != 0:
                out += "\n" + (res.stderr or "")
            return out
        except Exception:
            return ""

    try:
        raw = await asyncio.to_thread(_run_query, question)

        # If Axon reports no index, attempt to run `axon analyze` once, then retry
        if raw and ("no index" in raw.lower() or "run 'axon analyze'" in raw.lower()):
            logger.info("[mcp] axon index missing in %s, running 'axon analyze'", project_path)
            try:
                await asyncio.to_thread(subprocess.run, ["axon", "analyze", project_path], {"capture_output": True, "text": True, "timeout": 300})
            except Exception as e:
                logger.exception("[mcp] failed to run 'axon analyze': %s", e)
            # retry query after analyze
            raw = await asyncio.to_thread(_run_query, question)

        ctx = (raw or "")[:10000]
        if ctx:
            logger.info("[mcp] axon returned context length=%d", len(ctx))
            print(f"[mcp] axon context:\n{ctx}")
        else:
            logger.info("[mcp] axon returned empty context")
        return ctx
    except Exception as e:
        logger.exception("[mcp] failed to run axon query: %s", e)
        return ""


def _is_code_question(question: str) -> bool:
    lower = question.lower()
    return any(kw in lower for kw in CODE_KEYWORDS)
