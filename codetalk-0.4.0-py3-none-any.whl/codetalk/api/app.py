"""
FastAPI application — the public interface.
POST /chat   accepts a question, returns the LLM answer.
GET  /health returns 200 if the service is alive.
"""
from fastapi import FastAPI
import logging
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from codetalk.api import llm, mcp

app = FastAPI(title="codetalk", version="0.1.0")

# Ensure basic logging for uvicorn worker processes so `logger.info` is visible
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class ChatRequest(BaseModel):
    question: str


class ChatResponse(BaseModel):
    answer: str
    used_code_context: bool


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    # Log incoming user question (truncate if very long)
    safe_question = req.question if len(req.question) < 2000 else req.question[:10000]
    logger.info("[chat] user query:\n%s", safe_question)

    # Try to get structured context from Axon first
    code_context = await mcp.query(req.question)
    if code_context:
        logger.info("[chat] context from axon query:\n%s", code_context)
    else:
        logger.info("[chat] context from axon query: <empty>")

    answer = await llm.ask(
        question=req.question,
        code_context=code_context,
    )
    safe_answer = answer if len(answer) < 2000 else answer[:10000]
    logger.info("[chat] llm response:\n%s", safe_answer)
    return ChatResponse(
        answer=answer,
        used_code_context=bool(code_context),
    )
