"""
Ollama client — sends prompts to codellama:7b and returns the response.
When Axon context is available it is injected before the user question.
This is what prevents hallucination about code structure.
"""
import httpx

OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL = "codellama:7b"

SYSTEM_PROMPT = (
    "You are an expert code assistant. "
    "Help developers understand their codebase. "
    "When code context is provided, rely on it — never guess about code structure. "
    "Be concise. Use code blocks where helpful."
)


async def ask(question: str, code_context: str = "") -> str:
    prompt = _build_prompt(question, code_context)
    async with httpx.AsyncClient(timeout=120.0) as client:
        resp = await client.post(
            OLLAMA_URL,
            json={
                "model": MODEL,
                "prompt": prompt,
                "stream": False,
                "system": SYSTEM_PROMPT,
            },
        )
        resp.raise_for_status()
        return resp.json().get("response", "").strip()


def _build_prompt(question: str, code_context: str) -> str:
    """Inject Axon context if available — this is the zero-hallucination trick."""
    if code_context:
        return (
            f"### Code Context (from Axon)\n{code_context}\n\n"
            f"### Question\n{question}"
        )
    return question
