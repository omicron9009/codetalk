"""
Step 5: Serve the static chat UI on port 8080.
No Node.js. No build step. Just a single HTML file.
"""
import subprocess
from pathlib import Path


def start() -> subprocess.Popen:
    ui_dir = Path(__file__).parent.parent / "ui"
    proc = subprocess.Popen(
        ["python", "-m", "http.server", "8080", "--directory", str(ui_dir)]
    )
    return proc
