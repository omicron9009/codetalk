"""
Step 2: Expose Axon as an MCP server on port 8001.
This gives the LLM a structured way to query the code graph.
"""
import subprocess
from pathlib import Path


def start(project_path: Path) -> subprocess.Popen:
    """Launch `axon mcp` as a background process."""
    proc = subprocess.Popen(
        ["axon", "mcp", "--port", "8001"],
    )
    return proc
